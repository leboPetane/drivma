import React from 'react'

export const Lessons = () => {
    return (
        <div>
            <h1>Lessons</h1>
        </div>
    )
}
